
import { NativeModules } from 'react-native';

const { RNFirstLibrary } = NativeModules;


export default RNFirstLibrary;
